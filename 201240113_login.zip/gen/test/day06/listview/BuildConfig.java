/** Automatically generated file. DO NOT MODIFY */
package test.day06.listview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}