/** Automatically generated file. DO NOT MODIFY */
package com.example.memberlist_201240113;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}